#ifndef _FLMW_H
#define _FLMW_H

#include "lmw.h"

class snpdt;
class LMW;

class FLMW : public LMW
{
public:


protected:

};



#endif